<template>
  <div class="auth-container">
    <div class="auth-content">
      <div class="auth-form-section">
        <div class="auth-form-wrapper">
          <div class="auth-logo">
            <span class="logo-icon">🐾</span>
            <span class="logo-text">Pet Rescue</span>
          </div>
          <h1 class="auth-title">Join Pet Rescue</h1>
          <p class="auth-subtitle">Create an account to start helping animals</p>

          <form class="auth-form" @submit.prevent="handleSignup">
            <InputField 
              id="name"
              label="Full Name"
              placeholder="Enter your full name"
              v-model="name"
              required
            />
            
            <InputField 
              id="email"
              label="Email Address"
              type="email"
              placeholder="Enter your email"
              v-model="email"
              required
            />
            
            <InputField 
              id="password"
              label="Password"
              type="password"
              placeholder="Create a password"
              v-model="password"
              required
            />
            
            <InputField 
              id="confirm-password"
              label="Confirm Password"
              type="password"
              placeholder="Confirm your password"
              v-model="confirmPassword"
              required
            />

            <div class="form-options">
              <label class="checkbox-label">
                <input type="checkbox" name="terms" required>
                <span>I agree to the Terms and Conditions</span>
              </label>
            </div>

            <Button type="submit" variant="primary" :block="true">
              Create Account
            </Button>
          </form>

          <p class="auth-footer">
            Already have an account? 
            <RouterLink to="/login" class="link">Login</RouterLink>
          </p>

          <RouterLink to="/" class="back-link">← Back to Home</RouterLink>
        </div>
      </div>

      <div class="auth-image-section">
        <img src="/kucing.png" alt="Happy rescued cat">
        <div class="auth-image-overlay">
          <h2>Start Your Journey</h2>
          <p>Join thousands of animal lovers making a difference</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
// Gunakan <script setup> agar konsisten dengan komponen UI-mu
import { ref } from 'vue'

// Buat "wadah" reaktif untuk data form
const name = ref('')
const email = ref('')
const password = ref('')
const confirmPassword = ref('')

const handleSignup = () => {
  // Nanti, kamu bisa tambahkan logika signup di sini
  console.log('Form disubmit:', {
    name: name.value,
    email: email.value,
    password: password.value
  })
  alert('Akun berhasil dibuat! (Hanya pura-pura)')
}
</script>

<style scoped>

/* Kamu bisa tambahkan style khusus untuk auth-container, dll. di sini.
  Style untuk InputField dan Button akan diambil dari file komponennya.
*/
</style>