<template>
  <div class="auth-container">
    <div class="auth-content">
      <div class="auth-form-section">
        <div class="auth-form-wrapper">
          <div class="auth-logo">
            <span class="logo-icon">🐾</span>
            <span class="logo-text">Meong id</span>
          </div>
          <h1 class="auth-title">Welcome Back!</h1>
          <p class="auth-subtitle">Login to access your account</p>

          <form class="auth-form" @submit.prevent="handleLogin">
            <InputField
              id="email"
              label="Email Address"
              type="email"
              placeholder="Enter your email"
              v-model="email"
              required
            />

            <InputField
              id="password"
              label="Password"
              type="password"
              placeholder="Enter your password"
              v-model="password"
              required
            />

            <div class="form-options">
              <label class="checkbox-label">
                <input type="checkbox" name="remember" />
                <span>Remember me</span>
              </label>
              <RouterLink to="/forgot-password" class="link"
                >Forgot password?</RouterLink
              >
            </div>

            <Button type="submit" variant="primary" :block="true">
              Login
            </Button>
          </form>

          <p class="auth-footer">
            Don't have an account?
            <RouterLink to="/signup" class="link">Create Account</RouterLink>
          </p>

          <RouterLink to="/" class="back-link">← Back to Home</RouterLink>
        </div>
      </div>

      <div class="auth-image-section">
        <img
          src="/kucing.png"
          alt="Happy rescued cat"
        />
        <div class="auth-image-overlay">
          <h2>Welcome Back</h2>
          <p>We're so happy to see you again!</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { store } from '../store.js';

const router = useRouter();
// Buat "wadah" reaktif untuk data form
const email = ref("");
const password = ref("");

const handleLogin = () => {
  // Nanti, kamu bisa tambahkan logika login sesungguhnya di sini
  console.log("Login attempt:", {
    email: email.value,
    password: password.value,
  });
  alert("Login berhasil! (Hanya demo)");
  store.value.isLoggedIn = true

  router.push("/profile");
  // Nanti kamu bisa arahkan ke halaman lain pakai router.push('/')
};
</script>

<style scoped>
/* Kebanyakan style akan diambil dari style.css global-mu 
  (seperti .auth-container, dll.) 
*/

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.9rem;
  margin-bottom: 1.5rem;
}
</style>
