<template>
<!-- <header class="header">
        <div class="container">
            <nav class="nav">
                <div class="logo">
                    <a href="/">
                        <span class="logo-icon">🐾</span>
                        <span class="logo-text">Pet Rescue</span>
                    </a>
                </div>
                <ul class="nav-links">
                    <li><a href="/">Home</a></li>
                    <li><a href="/articles">Articles</a></li>
                    <li><a href="/adoption">Adoption</a></li>
                    <li><a href="/community">Community</a></li>
                    <li><a href="/donation" class="active">Donate</a></li>
                    <li><a href="/signup" class="btn-nav">Login</a></li>
                </ul>
            </nav>
        </div>
    </header> -->

    <main>
        <section class="page-header">
            <div class="container">
                <h1>Support Our Mission</h1>
                <p>Your donation helps us rescue, rehabilitate, and rehome animals in need</p>
            </div>
        </section>

        <section class="donation-section">
            <div class="container">
                <div class="donation-layout">
                    <div class="donation-form-wrapper">
                        <div class="donation-form-card">
                            <h2>Make a Difference Today</h2>
                            <p class="donation-subtitle">Every contribution helps save lives</p>

                            <form class="donation-form">
                                <div class="form-group">
                                    <label>Donation Type</label>
                                    <div class="donation-type-options">
                                        <label class="radio-label">
                                            <input type="radio" name="donation-type" value="one-time" checked>
                                            <span class="radio-button">One-time</span>
                                        </label>
                                        <label class="radio-label">
                                            <input type="radio" name="donation-type" value="monthly">
                                            <span class="radio-button">Monthly</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Donation Amount</label>
                                    <div class="amount-options">
                                        <label class="amount-button">
                                            <input type="radio" name="amount" value="25">
                                            <span>$25</span>
                                        </label>
                                        <label class="amount-button">
                                            <input type="radio" name="amount" value="50" checked>
                                            <span>$50</span>
                                        </label>
                                        <label class="amount-button">
                                            <input type="radio" name="amount" value="100">
                                            <span>$100</span>
                                        </label>
                                        <label class="amount-button">
                                            <input type="radio" name="amount" value="250">
                                            <span>$250</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="custom-amount">Custom Amount</label>
                                    <div class="input-with-icon">
                                        <span class="input-icon">$</span>
                                        <input type="number" id="custom-amount" name="custom-amount" placeholder="Enter custom amount">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="donor-name">Full Name</label>
                                    <input type="text" id="donor-name" name="donor-name" placeholder="Enter your name" required>
                                </div>

                                <div class="form-group">
                                    <label for="donor-email">Email Address</label>
                                    <input type="email" id="donor-email" name="donor-email" placeholder="your.email@example.com" required>
                                </div>

                                <div class="form-group">
                                    <label>Payment Method</label>
                                    <div class="payment-methods">
                                        <label class="payment-option">
                                            <input type="radio" name="payment" value="card" checked>
                                            <span class="payment-label">💳 Credit/Debit Card</span>
                                        </label>
                                        <label class="payment-option">
                                            <input type="radio" name="payment" value="paypal">
                                            <span class="payment-label">🅿️ PayPal</span>
                                        </label>
                                        <label class="payment-option">
                                            <input type="radio" name="payment" value="bank">
                                            <span class="payment-label">🏦 Bank Transfer</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="card-number">Card Number</label>
                                    <input type="text" id="card-number" name="card-number" placeholder="1234 5678 9012 3456" required>
                                </div>

                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="expiry">Expiry Date</label>
                                        <input type="text" id="expiry" name="expiry" placeholder="MM/YY" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="cvv">CVV</label>
                                        <input type="text" id="cvv" name="cvv" placeholder="123" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="anonymous">
                                        <span>Make this donation anonymous</span>
                                    </label>
                                </div>

                                <div class="form-group">
                                    <label for="message">Message (Optional)</label>
                                    <textarea id="message" name="message" rows="3" placeholder="Leave a message of support..."></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary btn-full btn-large">Complete Donation</button>

                                <p class="donation-note">Your donation is tax-deductible. You will receive a receipt via email.</p>
                            </form>
                        </div>
                    </div>

                    <aside class="donation-sidebar">
                        <div class="impact-card">
                            <h3>Your Impact</h3>
                            <div class="impact-item">
                                <div class="impact-amount">$25</div>
                                <p>Provides food for 5 rescued animals for a week</p>
                            </div>
                            <div class="impact-item">
                                <div class="impact-amount">$50</div>
                                <p>Covers basic veterinary care for one animal</p>
                            </div>
                            <div class="impact-item">
                                <div class="impact-amount">$100</div>
                                <p>Funds emergency medical treatment</p>
                            </div>
                            <div class="impact-item">
                                <div class="impact-amount">$250</div>
                                <p>Supports a full rescue operation from start to adoption</p>
                            </div>
                        </div>

                        <div class="stats-card">
                            <h3>2024 Impact</h3>
                            <div class="stat-box">
                                <div class="stat-number">1,247</div>
                                <div class="stat-label">Animals Rescued</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-number">892</div>
                                <div class="stat-label">Successful Adoptions</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-number">356</div>
                                <div class="stat-label">Foster Homes</div>
                            </div>
                        </div>

                        <div class="testimonial-card">
                            <p>"Thanks to Pet Rescue, I found my best friend. The work they do is truly life-changing for both animals and families."</p>
                            <p class="testimonial-author">- Sarah M.</p>
                        </div>
                    </aside>
                </div>
            </div>
        </section>
    </main>

    <!-- <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>About Pet Rescue</h3>
                    <p>We are dedicated to rescuing, rehabilitating, and rehoming animals in need. Every life matters, and together we can make a difference.</p>
                </div>
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="/adoption">Adoption</a></li>
                        <li><a href="/foster">Foster Home</a></li>
                        <li><a href="/report">Report Animal</a></li>
                        <li><a href="/articles">Articles</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Contact Us</h3>
                    <ul class="footer-contact">
                        <li>📧 info@petrescue.org</li>
                        <li>📞 +1 (555) 123-4567</li>
                        <li>📍 123 Rescue Street, City, State</li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Follow Us</h3>
                    <div class="social-links">
                        <a href="#" class="social-link">Facebook</a>
                        <a href="#" class="social-link">Instagram</a>
                        <a href="#" class="social-link">Twitter</a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 Pet Rescue. All rights reserved. Made with 💚 for animals in need.</p>
            </div>
        </div>
    </footer> -->
</template>

<script>
export default { name: 'DonationView' }
</script>

<style scoped>
</style>
