<script setup>
import { ref } from 'vue'
// Gunakan RouterLink untuk navigasi di Vue, ini lebih baik dari <a href>
import { RouterLink } from 'vue-router'

// 1. Variabel reaktif untuk melacak status sidebar
const isSidebarOpen = ref(false)

// 2. Fungsi untuk mengubah status (membuka/menutup)
const toggleSidebar = () => {
  isSidebarOpen.value = !isSidebarOpen.value
}

// 3. Fungsi untuk menutup sidebar (dipakai saat link diklik)
const closeSidebar = () => {
  isSidebarOpen.value = false
}
</script>

<template>
  <header class="header">
    <div class="container">
      <nav class="nav">
        <div class="logo">
          <RouterLink to="/" @click="closeSidebar">
            <span class="logo-icon">🐾</span>
            <span class="logo-text">Meong id</span>
          </RouterLink>
        </div>

    <ul class="nav-links" :class="{ 'nav-open': isSidebarOpen }">
          <li><RouterLink to="/" @click="closeSidebar">Home</RouterLink></li>
          <li><RouterLink to="/articles" @click="closeSidebar">Artikel</RouterLink></li>
          <li><RouterLink to="/donation" @click="closeSidebar">Donasi</RouterLink></li>
          <li><RouterLink to="/login" @click="closeSidebar">Login</RouterLink></li>
        </ul>

        <button class="nav-toggle" @click="toggleSidebar" :class="{ 'is-active': isSidebarOpen }">
          <span class="hamburger-bar"></span>
          <span class="hamburger-bar"></span>
          <span class="hamburger-bar"></span>
        </button>
      </nav>
    </div>

    <div 
      class="nav-overlay" 
      v-if="isSidebarOpen" 
      @click="toggleSidebar"
    ></div>
  </header>
</template>

<style scoped>
/* Style Dasar untuk Header & Navigasi Desktop */
.header {
  background: #fff;
  border-bottom: 1px solid #eee;
  padding: 1rem 0;
  position: sticky;
  top: 0;
  z-index: 1000;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

.nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo a {
  display: flex;
  align-items: center;
  text-decoration: none;
  color: #333;
  font-weight: 700;
}

.logo-icon {
  font-size: 1.5rem;
  margin-right: 0.5rem;
}

.logo-text {
  font-size: 1.2rem;
}

.nav-links {
  display: flex;
  align-items: center;
  list-style: none;
  gap: 1.5rem;
  margin: 0;
  padding: 0;
}

.nav-links li {
  padding: 0;
}

.nav-links a {
  text-decoration: none;
  color: #555;
  font-weight: 600;
  /* PERBAIKAN: Beri padding & radius ke SEMUA link agar tidak "lompat" */
  padding: 0.5rem 1rem;
  border-radius: 8px;
  /* PERBAIKAN: Transisi untuk semua properti (termasuk background) */
  transition: all 0.2s;
}

.nav-links a:hover,
.nav-links a.router-link-exact-active {
  background: #A9C47F; /* Warna primer-mu */
  color: white;
}


/* Tombol Hamburger (Sembunyi di Desktop) */
.nav-toggle {
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  z-index: 1050; /* Di atas sidebar tapi di bawah overlay (jika perlu) */
}

.hamburger-bar {
  display: block;
  width: 25px;
  height: 3px;
  background-color: #333;
  margin: 5px 0;
  transition: all 0.3s ease;
}

/* Animasi Tombol Hamburger (opsional, tapi keren) */
.nav-toggle.is-active .hamburger-bar:nth-child(1) {
  transform: translateY(8px) rotate(45deg);
}
.nav-toggle.is-active .hamburger-bar:nth-child(2) {
  opacity: 0;
}
.nav-toggle.is-active .hamburger-bar:nth-child(3) {
  transform: translateY(-8px) rotate(-45deg);
}


/* Overlay (Latar belakang gelap di HP) */
.nav-overlay {
  display: none; /* Sembunyi di desktop */
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1001; /* Di bawah sidebar, di atas konten */
}


/* RESPONSIVE (TAMPILAN HP) 
  Ini adalah intinya: @media query
  Gaya di bawah ini hanya berlaku jika lebar layar 768px atau kurang
*/
@media (max-width: 768px) {
  
  /* 1. Tampilkan tombol hamburger */
  .nav-toggle {
    display: block;
  }

  /* 2. Tampilkan overlay saat nav terbuka */
  .nav-overlay {
    display: block;
  }

  /* 3. Ubah .nav-links menjadi Sidebar */
  .nav-links {
    position: fixed; /* Tetap di layar */
    top: 0;
    left: 0;
    height: 100%; /* Setinggi layar */
    width: 250px; /* Lebar sidebar */
    
    /* Gunakan warna putih gading-mu! */
    background: #FFFFF0; 
    
    flex-direction: column; /* Tumpuk link ke bawah */
    align-items: flex-start;
    padding: 3rem 2rem; /* Beri jarak di dalam sidebar */
    gap: 2rem;
    
    box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    z-index: 1002; /* Paling depan */

    /* 4. Sembunyikan sidebar di luar layar secara default */
    transform: translateX(-100%);
    transition: transform 0.3s ease-out;
  }

  /* 5. Tampilkan sidebar jika class .nav-open ada */
  .nav-links.nav-open {
    transform: translateX(0);
  }

  .nav-links a {
    font-size: 1.1rem;
  }
}
</style>