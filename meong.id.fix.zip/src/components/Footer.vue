<template>
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <h3>About Meong.id</h3>
          <p>Proyek demo hasil konversi HTML → Vue. Silakan sesuaikan isinya.</p>
        </div>
        <div class="footer-section">
          <h3>Quick Links</h3>
          <ul class="footer-links">
            <li><RouterLink to="/adoption">Adoption</RouterLink></li>
            <li><RouterLink to="/foster">Foster Home</RouterLink></li>
            <li><RouterLink to="/report">Report</RouterLink></li>
          </ul>
        </div>
        <div class="footer-section">
          <h3>Contact</h3>
          <p>Email: info@meong.id</p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2025 Meong.id — All rights reserved</p>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'FooterComp'
}
</script>

<style scoped>
.footer-bottom { text-align:center; padding-top:1rem; border-top:1px solid rgba(255,255,255,0.2); }
</style>
