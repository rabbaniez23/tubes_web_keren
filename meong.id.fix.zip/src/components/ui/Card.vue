<template>
  <div class="card">
    <figure>
      <slot name="image"></slot>
    </figure>
    <div class="card-body">
      <slot name="title"></slot>
      
      <slot name="content"></slot>
      
      <div class="card-actions">
        <slot name="actions"></slot>
      </div>
    </div>
  </div>
</template>

<script setup>
// Tidak perlu script, semua sudah di handle oleh props/slots
</script>

<style scoped>
.card {
  background: #ffffff; /* (bg-base-100) */
  border-radius: 12px;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06); /* (shadow-sm) */
  overflow: hidden;
  display: flex;
  flex-direction: column;
  width: 100%; /* Kartu akan mengisi grid column */
}

figure {
  margin: 0;
  padding: 0;
  position: relative;
  overflow: hidden;
}

/* Styling :deep() ini akan men-style <img> 
  yang kamu masukkan ke dalam slot 'image' dari HomeView.vue 
*/
:deep(figure > img) {
  display: block;
  width: 100%;
  height: 200px; /* Kita set tinggi gambar agar seragam */
  object-fit: cover; /* Ini penting agar gambar tidak gepeng */
  transition: transform 0.3s ease;
}

.card:hover :deep(figure > img) {
  transform: scale(1.05); /* Efek zoom saat di-hover */
}

.card-body {
  padding: 1.5rem; /* (card-body padding) */
  display: flex;
  flex-direction: column;
  flex-grow: 1; /* Ini membuat card-body mengisi sisa ruang */
}

/* Ini akan men-style <h3> yang kamu masukkan 
  ke dalam slot 'title' 
*/
:deep(.card-body > h3) {
  font-size: 1.25rem;
  font-weight: 700;
  margin: 0 0 0.5rem 0;
}

/* Ini akan men-style <p> yang kamu masukkan 
  ke dalam slot 'content' 
*/
:deep(.card-body > p) {
  color: #555;
  flex-grow: 1; /* Ini mendorong 'actions' ke bawah */
  margin: 0 0 1rem 0;
}

.card-actions {
  margin-top: auto; /* Mendorong ke bawah */
  display: flex;
  justify-content: flex-end; /* (justify-end) */
}
</style>