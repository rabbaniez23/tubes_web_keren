<template>
  <aside class="sidebar">
    <div class="logo">
      <RouterLink to="/">
        <span class="logo-icon">🐾</span>
        <span class="logo-text">Meong id</span>
      </RouterLink>
    </div>

    <nav class="sidebar-nav">
      <ul>
        <li><RouterLink to="/">Beranda</RouterLink></li>
        <li><RouterLink to="/report">Lapor Kucing</RouterLink></li>
        <li><RouterLink to="/adoption">Adopsi Kucing</RouterLink></li>
        <li><RouterLink to="/foster">Rumah Sakit/Shelter</RouterLink></li>
        <li><RouterLink to="/articles">Artikel</RouterLink></li>
        <li><RouterLink to="/community">Komunitas</RouterLink></li>
        <li><RouterLink to="/donation">Donasi</RouterLink></li>
        <li><RouterLink to="/profile">Profile</RouterLink></li>
      </ul>
    </nav>
  </aside>
</template>

<script setup>
import { RouterLink } from 'vue-router'
</script>

<style scoped>
.sidebar {
  width: 250px; /* Lebar sidebar */
  position: fixed; /* Tetap di kiri layar */
  top: 0;
  left: 0;
  height: 100vh; /* Setinggi layar */
  background: #fff;
  border-right: 1px solid #eee;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  z-index: 1000;
  box-shadow: 2px 0 10px rgba(0,0,0,0.05);
  transition: transform 0.3s ease;
}

.logo {
  margin-bottom: 2rem;
}

.logo a {
  display: flex;
  align-items: center;
  text-decoration: none;
  color: #333;
  font-weight: 700;
}
.logo-icon {
  font-size: 1.5rem;
  margin-right: 0.5rem;
}
.logo-text {
  font-size: 1.2rem;
}

.sidebar-nav ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 0.5rem; /* Jarak antar link */
}

.sidebar-nav a {
  display: block;
  text-decoration: none;
  color: #555;
  font-weight: 600;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  transition: all 0.2s;
}

/* Style untuk link yang aktif */
.sidebar-nav a:hover {
  background: #A9C47F; /* Warna primer-mu */
  color: white;
}
</style>